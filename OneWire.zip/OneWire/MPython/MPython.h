#ifndef __MPYTHON_H
#define __MPYTHON_H

#if ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif

#include <Wire.h>
#include <Adafruit_NeoPixel.h>
#include <DFRobot_SSD1306_I2C.h>


#define MSA300_I2C_ADDR 38

//To the beat
#define    Whole       1
#define    Half        2
#define    Quarter     4
#define    Eighth      8
#define    Sixteenth   16
#define    Double      32
#define    Breve       64

//Play beat
enum Beat {
    BEAT_1 = 1,
    BEAT_1_2 = 2,
    BEAT_1_4 = 4,
    BEAT_2 = 32,
    BEAT_4 = 64
};


class MPython{
public:
    MPython();
    void begin(void);
};

class MSA300{
public:
    MSA300();

	void init(void);
    float getX(void);
    float getY(void);
    float getZ(void);
	float getStrength(void);
};


typedef void (*CBFunc)(void); 

class Button
{
public:
    Button(uint8_t _io);
	Button(uint8_t _io1, uint8_t _io2);
	bool isPressed(void);
	void setPressedCallback(CBFunc _cb);
	void setUnPressedCallback(CBFunc _cb);
private:
	CBFunc pressedCb;
	CBFunc unpressedCb;
	uint8_t io;
	uint8_t io1;
	uint8_t io2;
	uint8_t pinNum;
	bool prevState;
	
	static void taskLoop(void *param){
		Button *self = (Button *)param;
		while(1){
			bool isPressed = self->isPressed();
			if(self->prevState != isPressed){
				Serial.printf("button change prevState=%d current=%d\n",(int)self->prevState,(int)isPressed);
				if(isPressed && self->pressedCb){
					self->pressedCb();
				}
				if((!isPressed) && self->unpressedCb){
					self->unpressedCb();
				}
				self->prevState = isPressed;
				Serial.printf("button change prevState=%d\n",(int)self->prevState);
			}
			yield();
		}
	}
};

class TouchPad
{
public:
	TouchPad(uint8_t _io);
	bool isTouched(void);
	void setTouchedCallback(CBFunc _cb);
	void setUnTouchedCallback(CBFunc _cb);
private:
	CBFunc touchedCb;
	CBFunc untouchedCb;
	uint8_t io;
	int valuePrevPrev,valuePrev,value;
	static void taskLoop(void *param){
		bool prevState = false;
		TouchPad *self = (TouchPad *)param;
		while(1){
			bool isTouched = self->isTouched();
			if(prevState != isTouched){
				if(isTouched && self->touchedCb){
					self->touchedCb();
				}
				if((!isTouched) && self->untouchedCb){
					self->untouchedCb();
				}
				prevState = isTouched;
			}
			delay(20);
		}
	}
};

class AnalogPin
{
public:
	AnalogPin(uint8_t _io);
    uint16_t read();
private:
    uint8_t io;
};

class RGB
{
public:
	RGB();
	void write(uint8_t index, uint8_t r, uint8_t g, uint8_t b);
	void write(uint8_t index, uint32_t color){write(index, 0xff&(color>>16), 0xff&(color>>8), 0xff&color);}
	void brightness(uint8_t b);
	uint8_t brightness();
private:
	uint8_t _brightness;
	uint32_t c[3];
};

class Buzz
{
public:
	Buzz();
	void on(void);
	void off(void);
	bool isOn(void);
	void freq(uint32_t _freq=500);
	void freq(int _freq=500){freq((uint32_t)_freq);};
	void freq(double _freq=500.0){freq((uint32_t)_freq);};

	void freq(uint32_t _freq, Beat beat);
	void freq(int _freq, Beat beat){freq((uint32_t)_freq, beat);};
	void freq(double _freq, Beat beat){freq((uint32_t)_freq, beat);};
	void freq(uint32_t _freq, double beat);
	void freq(uint32_t _freq, uint32_t beat){freq(_freq, (double)beat);};
	void freq(uint32_t _freq, int beat){freq(_freq, (double)beat);};
private:
	uint16_t _freq;
	bool _on;
};

extern MPython mPython;
extern Button buttonA,buttonB,buttonAB;
extern Adafruit_NeoPixel pixels;
extern DFRobot_SSD1306_I2C display;
extern TouchPad touchPadP,touchPadY,touchPadT,touchPadH,touchPadO,touchPadN;
extern Buzz buzz;
extern AnalogPin light,sound;
extern RGB rgb;
extern MSA300 accelerometer;
#endif
